/**
 * @file main.c
 * @brief Program entry point.  Runs the teeny tiny shell
 *
 * Course: CSC3210
 * Section: 003
 * Assignment: Teeny Tiny Shell with Pipes
 * Name: Hudson Arney
 */

#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include "ttsh.h"

/**
 * @brief Reads a string of user input
 * @param dest - buffer for user input string
 * @return 0 on success
 * @return -1 on error
 */
int read_cmd_string(char dest[INPUT_MAX])
{

    // Read user input
    if (fgets(dest, INPUT_MAX, stdin) == NULL)
    {
        fprintf(stderr, "Unable to read user input\n");
        return -1;
    }

    // Remove trailing return character
    int len = strlen(dest);
    if (dest[len - 1] == '\n')
    {
        dest[len - 1] = '\0';
    }

    return 0;
}

/**
 * @brief Parses a string and divides it into individual commands
 * @param input - string containing user input
 * @param cmd_strs - the target array for command strings
 * @return the number of commands found in the input
 * @return -1 on error
 */
int parse_commands(char input[INPUT_MAX], char cmd_strs[CMD_MAX][INPUT_MAX])
{

    // Chop the input into command strings
    int cmd_count = 0;
    char *cmd_ptr = strtok(input, ";");
    while (cmd_ptr)
    {
        if (cmd_count >= CMD_MAX)
        {
            fprintf(stderr, "Too many commands\n");
            return -1;
        }
        strncpy(cmd_strs[cmd_count], cmd_ptr, INPUT_MAX);
        cmd_count++;
        cmd_ptr = strtok(NULL, ";");
    }

    return cmd_count;
}

/**
 * @brief Program entry procedure for the shell
 */
int main()
{
    char user_input[INPUT_MAX];
    char cmd_strs[CMD_MAX][INPUT_MAX];
    int stop = 0;
    while (!stop)
    {

        // Print the input prompt
        printf("$> ");

        // Read user input
        if (read_cmd_string(user_input) == -1)
        {
            return 1;
        }

        // Chop the input into command strings
        int cmd_count = parse_commands(user_input, cmd_strs);
        if (cmd_count == -1)
        {
            return 1;
        }

        // Chop the commands into arguments and execute one at a time
        for (int i = 0; i < cmd_count; i++)
        {
            // ITERATE THROUGH EACH COMMAND
            // SPLIT ON EACH "|", INCREMENTING SOME PIPE VAL
            // IF PIPE VAL (# of pipe-connected processes in singular command) > 1, 
            // add each to another array of size <COMMAND MAX>)
            // DUP THE BEGINNING AND END TO BE
            // EXECUTE EACH OF THE PROCESSES

            char *pipe_commands[5];
            char *pipe_tok = strtok(cmd_strs[i], "|");
            int pipe_count = 0;
            while (pipe_tok != NULL)
            {
                pipe_commands[pipe_count++] = pipe_tok;
                pipe_tok = strtok(NULL, "|");
            }
            if (strcmp(pipe_commands[0], "quit") == 0)
            {
                return 1;
            }

            // CREATE THE PIPES:
            int pipes[pipe_count - 1][2];
            if (pipe_count > 1)
            {
                for (int j = 0; j < pipe_count - 1; j++)
                {
                    int cur_pipe[2];
                    if (pipe(cur_pipe) == -1)
                    {
                        printf("Could not pipe: %s\n", strerror(errno));
                        return -1;
                    }
                    pipes[j][0] = cur_pipe[0];
                    pipes[j][1] = cur_pipe[1];
                }
            }

            // WE NOW HAVE AN ARRAY OF PIPE COMMANDS (LIKE [ls -al, grep 'hello']) and we should now:
            // CHECK if the LIST IS >1. IF IT IS:

            for (int k = 0; k < pipe_count; k++)
            {
                char *args[10];
                char *tok = strtok(pipe_commands[k], " ");
                int arg_count = 0;
                while (tok != NULL)
                {
                    args[arg_count++] = tok;
                    tok = strtok(NULL, " ");
                }
                args[arg_count] = NULL;

                if (strcmp(args[0], "quit") == 0)
                {
                    return 1;
                }

                pid_t pid = fork();
                if (pid == -1)
                {
                    fprintf(stderr, "Fork failed: %s\n", strerror(errno));
                    return 1;
                }
                else if (pid == 0 && k == 0)
                {
                    dup2(pipes[0][1], STDOUT_FILENO);
                    close(pipes[0][0]);
                    close(pipes[0][1]);

                    execvp(args[0], args);
                    fprintf(stderr, "Command not Found: %s\n", strerror(errno));
                    return 1;
                }
                else if (pid == 0 && k < pipe_count - 1)
                {
                    // dup STDIN TO THE READ END OF THE Kth-1 PIPE and STDOUT TO THE WRITE END OF THE Kth pipe
                    dup2(pipes[k][0], STDIN_FILENO);
                    dup2(pipes[k + 1][1], STDOUT_FILENO);
                    close(pipes[k][0]);
                    close(pipes[k][1]);
                    close(pipes[k + 1][0]);
                    close(pipes[k + 1][1]);

                    execvp(args[0], args);
                    fprintf(stderr, "Command not Found: %s\n", strerror(errno));
                    return 1;
                }
                else if (pid == 0 && k == pipe_count - 1)
                {
                    // dup STDIN TO THE READ END OF THE Kth-1 pipe, LEAVING STDOUT AS SUCH
                    dup2(pipes[k - 1][0], STDIN_FILENO);
                    close(pipes[k - 1][0]);
                    close(pipes[k - 1][1]);

                    execvp(args[0], args);
                    fprintf(stderr, "Command not Found: %s\n", strerror(errno));
                    return 1;
                }
            }
            // parent: CLOSE ALL OF THE PIPES
            for (int s = 0; s < pipe_count - 1; s++)
            {
                close(pipes[s][0]);
                close(pipes[s][1]);
            }
            for (int m = 0; m < pipe_count; m++)
            {
                wait(NULL);
            }
        }
    }
    return 0;
}