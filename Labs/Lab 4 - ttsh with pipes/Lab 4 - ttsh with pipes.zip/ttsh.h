#ifndef TTSH_H
#define TTSH_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define INPUT_MAX 256
#define ARGS_MAX 10
#define CMD_MAX 5

// Function prototypes
int parse_commands(char input[INPUT_MAX], char cmd_strs[CMD_MAX][INPUT_MAX]);
int read_cmd_string(char dest[INPUT_MAX]);

#endif /* TTSH_H */
